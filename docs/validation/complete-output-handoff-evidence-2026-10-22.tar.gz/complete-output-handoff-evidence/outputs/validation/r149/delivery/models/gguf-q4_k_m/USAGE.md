# 本地模型交接

来源训练：wb-0dfbfbee65f040e3bf4e2d023646783e；精度：q4_k_m。

模型经过格式转换或量化，源 HF 评测分数不能视为当前 GGUF 的业务成绩。请用同题、同生成与评分协议重新验证，当前业务验证状态为 not_run。

训练和工作台评测使用下列原始提示（删除答案，保留 Response 后的换行）：

```text
### Instruction:
[训练时的业务指令]

### Input:
[业务输入]

### Response:
```

没有输入时省略整个 Input 段。不要把占位文本当作实际业务指令。Modelfile 的 TEMPLATE 直接使用传入的完整提示；Ollama 调用须提供上述完整文本。LM Studio 聊天界面可能使用基座聊天模板，与原始提示不同；业务对照应使用不附加聊天模板的原始文本生成。

GGUF 内保存源 tokenizer 的聊天模板供兼容工具使用；保留它不代表训练采用了该聊天模板。hf_tokenizer/ 保存实际转换的 HF 分词文件，用于工作台的输入 token 核对与统一解码。可在成功训练记录下选择 GGUF 同题对照；评测结果保存在独立报告中，不回写导出时的 not_run 状态。文件和来源摘要见 export_evidence.json。
