#!/usr/bin/env python3
"""Prepare R149 through real workbench gates; never start training or inference.

This developer-authored synthetic integration evidence is not business validation.
Only the selected fresh output directory is written. The data author knows the
synthetic labels; test is not blind to its author. No script-level parsing of a
materialized test partition and no test generation/scoring are performed.
Product freeze/preflight integrity checks still read all partitions internally.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO))
MAPPING = {"amber": "L8", "birch": "R3", "cobalt": "V6", "dahlia": "N1"}
GOAL = (
    "这是开发者集成用的合成分类任务：根据 signal 字段，从训练标签学习固定的 route 映射。"
    "只输出 route 处理码本身，只允许 L8、R3、V6、N1，不要解释、标点、代码块或其他文字。"
    "ticket 与备注不决定类别。"
)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument(
        "--llama-cpp-dir",
        default=str(REPO / "outputs/local-tools/llama.cpp-436f6f89e1e5"),
    )
    args = parser.parse_args()
    base = Path(args.model_path).expanduser().resolve()
    if not base.is_dir():
        parser.error("A complete existing local model is required; no downloads.")
    out = Path(args.output_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=False)
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["HF_DATASETS_OFFLINE"] = "1"
    os.environ["HF_DATASETS_CACHE"] = str(out / "cache/datasets")
    started = time.monotonic()

    def event(kind, **kwargs):
        item = {"event": kind, "elapsed_seconds": time.monotonic() - started, **kwargs}
        with (out / "progress.jsonl").open("a") as f:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
        print(json.dumps(item, ensure_ascii=False), flush=True)

    from src.workbench.baseline_analysis import propose_baseline_analysis
    from src.workbench.evaluation_suites import EvalSuiteService
    from src.workbench.intake_service import IntakeService
    from src.workbench.training_runs import TrainingRunService

    rows = []
    for nuisance in range(20):
        ticket = f"R149-T{nuisance:02d}"
        # Unique per ticket prevents identical rendered inputs connecting all
        # ticket groups. Each note occurs under every signal, so it carries no class.
        note = f"合成受理记录批次 NX-{nuisance:02d}；备注只作上下文，不决定处理码。"
        for signal, route in MAPPING.items():
            rows.append({"ticket": ticket, "signal": signal, "note": note, "route": route})
    assert len(rows) == 80
    for signal in MAPPING:
        assert {(r["ticket"], r["note"]) for r in rows if r["signal"] == signal} == {
            (r["ticket"], r["note"]) for r in rows
        }
    raw = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode()
    (out / "synthetic-source.jsonl").write_bytes(raw)
    write(
        out / "design.json",
        {
            "scope": "R149 developer synthetic workbench integration, not north-star/business success",
            "goal": GOAL,
            "developer_source_rule_not_model_prompt": MAPPING,
            "data": "4 signals x 20 shared ticket/note nuisance combinations; 80 counterfactual rows, 20 synthetic groups",
            "grouping": "ticket; ordinary seed42 80/10/10 group split, no reshuffling based on blind questions or scores",
            "business_role_simulation": "Developer explicitly chooses route target and ticket grouping, confirms previews; answers hidden-input blind challenge by predeclared rule, not copied data_label. Data author knows all synthetic labels.",
            "test_policy": "No script-level parsing of materialized test or test suite cases; no test generation/scoring. Mandatory product freeze/preflight internally read/check all partitions. Original source is author-known, test is not author-blind.",
            "fixed_suite": "Frozen before any training.prepare/start; no changes based on scores",
            "next_phase_not_authorized_by_this_script": "start real workbench run; dev-only base/adapter/merged HF/GGUF Q4_K_M same-question strict token-contract generation; no test scoring",
            "source_sha256": sha(out / "synthetic-source.jsonl"),
            "script_sha256": sha(__file__),
        },
    )
    intake = IntakeService(out / "intake")
    session = intake.create(
        GOAL,
        "synthetic-source.jsonl",
        raw,
        scope="full",
        data_description="80 developer-authored counterfactual rows in 20 synthetic ticket groups; labels generated by a predeclared nonce mapping; no independent real business examples.",
    )
    analysis = propose_baseline_analysis(
        session, target_column="route", group_columns=["ticket"], instruction=GOAL
    )
    assert [f.column for f in analysis.recipe.inputs] == ["signal", "note"]
    assert [f.column for f in analysis.recipe.targets] == ["route"]
    assert analysis.recipe.group_columns == ["ticket"]
    assert all(not f.transforms for f in analysis.recipe.targets)
    # The allowed label set is explicit; the signal->label mapping is absent.
    assert all(f"{signal}→{route}" not in GOAL for signal, route in MAPPING.items())
    session = intake.apply_analysis(session, analysis, model="")
    event("basic_analysis", session_id=session.session_id, agent_model=session.agent_model)
    write(out / "basic-analysis.json", analysis.model_dump())
    assert session.preview.counts.get("ready") == 80
    for row in session.preview.rows:
        signal = row.original["signal"]
        assert row.target == MAPPING[signal]
        assert "route" not in row.input and row.original["route"] not in row.input
    session = intake.confirm(session.session_id, session.revision)
    session = intake.validate_full_data(session.session_id, session.revision)
    assert not any(issue.severity == "blocking" for issue in session.full_data.issues)
    write(out / "full-validation-review.json", session.full_data.model_dump())
    session = intake.confirm_full_data(session.session_id, session.revision)
    session = intake.materialize_dataset(
        session.session_id,
        session.revision,
        name="r149-counterbalanced-route",
        registry_root=out / "datasets",
        validation_fraction=0.1,
        test_fraction=0.1,
        seed=42,
        independent_rows_confirmed=False,
    )
    initial_artifact = session.dataset.model_dump()
    write(out / "initial-materialized-artifact.json", initial_artifact)
    assert initial_artifact["statistics"]["row_counts"] == {"train": 64, "validation": 8, "test": 8}
    suite = EvalSuiteService(out / "evaluation-suites").freeze(session)
    session = intake.materialize_dataset(
        session.session_id,
        session.revision,
        name="r149-counterbalanced-route",
        registry_root=out / "datasets",
        evaluation_suite=suite,
    )
    assert session.dataset.statistics["row_counts"] == {"train": 64, "validation": 8, "test": 8}
    assert session.dataset.evaluation_suite == suite
    artifact = session.dataset.model_dump()
    write(out / "frozen-materialized-artifact.json", artifact)
    # Only train/dev artifacts are parsed at script level. Counts and hashes for
    # test come from generated immutable metadata, not opening its row file.
    partitions = {}
    for split in ("train", "validation"):
        partitions[split] = [
            json.loads(line) for line in Path(artifact["paths"][split]).read_text().splitlines()
        ]
    group_sets = {
        split: {row["metadata"]["group"]["ticket"] for row in records}
        for split, records in partitions.items()
    }
    assert not group_sets["train"] & group_sets["validation"]
    test_groups = {row["ticket"] for row in rows} - group_sets["train"] - group_sets["validation"]
    assert (
        len(group_sets["train"]) == 16
        and len(group_sets["validation"]) == 2
        and len(test_groups) == 2
    )
    for split, records in partitions.items():
        for ticket in group_sets[split]:
            selected = [r for r in records if r["metadata"]["group"]["ticket"] == ticket]
            assert len(selected) == 4 and {r["output"] for r in selected} == set(MAPPING.values())
    manifest = json.loads(Path(artifact["paths"]["manifest"]).read_text())
    test_seal = dict(manifest["splits"]["test"])
    event(
        "suite_frozen",
        suite_id=suite["suite_id"],
        dataset_version=session.dataset.version,
        counts=artifact["statistics"]["row_counts"],
    )
    training = TrainingRunService(out / "runs", project_root=REPO, python_executable=sys.executable)
    options = {
        "num_epochs": 1,
        "batch_size": 1,
        "gradient_accumulation_steps": 1,
        "learning_rate": 2e-4,
        "weight_decay": 0.0,
        "warmup_ratio": 0.0,
        "lr_scheduler_type": "constant",
        "logging_steps": 1,
        "save_steps": 1000,
        "eval_steps": 1000,
        "save_total_limit": 1,
        "gradient_checkpointing": False,
        "fp16": False,
        "bf16": False,
        "seed": 42,
        "optim": "adamw_torch",
    }
    lora = {
        "r": 8,
        "lora_alpha": 16,
        "target_modules": "all-linear",
        "lora_dropout": 0.0,
        "bias": "none",
    }
    kwargs = {
        "max_length": 192,
        "sft_protocol": "alpaca_answer_only_v1",
        "training_options": options,
        "lora_options": lora,
        "model_options": {"torch_dtype": "float32", "quantization_bits": None, "device_map": None},
    }
    blocked = training.prepare(session, base, **kwargs)
    assert blocked["status"] == "blocked"
    assert any("盲标" in issue["message"] for issue in blocked["issues"])
    write(out / "blind-gate-blocked-run.json", blocked)
    challenge = intake.start_label_verification(session.session_id, session.revision, sample_size=8)
    write(out / "blind-hidden-input-challenge.json", challenge)
    answers = {}
    for item in challenge["items"]:
        assert "target" not in item and "data_label" not in item and "output" not in item
        found = re.findall(r"signal[：:]\s*(amber|birch|cobalt|dahlia)\b", item["input"])
        assert len(found) == 1, item["input"]
        answers[item["row_id"]] = MAPPING[found[0]]
    result = intake.submit_label_verification(
        session.session_id, challenge["verification_id"], answers
    )
    assert result["verdict"] == "verified"
    write(
        out / "blind-rule-submission.json",
        {
            "source": "Predeclared synthetic developer rule applied only to hidden challenge input; no data_label lookup",
            "answers": answers,
            "result": result,
        },
    )
    session = intake.load(session.session_id)
    prepared = training.prepare(session, base, **kwargs)
    write(out / "prepared-run.json", prepared)
    if prepared["status"] != "prepared":
        event("prepare_blocked", issues=prepared["issues"])
        raise ValueError(
            "Real product prepare blocked; preserve evidence and resolve without bypassing gates."
        )
    assert prepared["config"]["data"]["validation_split"] == 0
    assert prepared["config"]["data"]["sft_protocol"] == "alpaca_answer_only_v1"
    assert not (out / "runs" / prepared["run_id"] / "started").exists()
    assert not Path(prepared["output_dir"]).exists()
    llama = Path(args.llama_cpp_dir).expanduser().resolve()
    quantizer = llama / "build/bin/llama-quantize"
    runtime = llama / "build-tunesmith-eval/bin/tunesmith-gguf-eval"
    inventory = {
        "directory": str(llama),
        "revision": subprocess.check_output(
            ["git", "-C", str(llama), "rev-parse", "HEAD"], text=True
        ).strip(),
        "files": {
            str(p.relative_to(llama)): {
                "exists": p.is_file(),
                **({"sha256": sha(p), "size": p.stat().st_size} if p.is_file() else {}),
            }
            for p in [llama / "convert_hf_to_gguf.py", quantizer, runtime]
        },
        "note": "Read-only inventory; binaries not executed, no install/build/download, no LM Studio changes. Real export/runtime checks remain for authorized next phase.",
    }
    assert inventory["revision"] == "436f6f89e1e581249900b37a5b8a12a36a6d0912"
    write(out / "existing-tools-inventory.json", inventory)
    by_source_id = {row.row_id: row for row in session.full_data.preview.rows}
    blind_test_intersection = sorted(
        {by_source_id[item["row_id"]].group["ticket"] for item in challenge["items"]} & test_groups
    )
    summary = {
        "status": "prepared_not_started",
        "scope": "synthetic developer integration only",
        "session_id": session.session_id,
        "session_revision": session.revision,
        "run_id": prepared["run_id"],
        "blocked_before_blind_run_id": blocked["run_id"],
        "dataset_name": session.dataset.name,
        "dataset_version": session.dataset.version,
        "suite": suite,
        "config_digest": prepared["config_digest"],
        "row_counts": artifact["statistics"]["row_counts"],
        "group_counts": artifact["statistics"]["group_counts"],
        "train_groups": sorted(group_sets["train"]),
        "development_groups": sorted(group_sets["validation"]),
        "test_groups_inferred_by_complement_not_test_file_read": sorted(test_groups),
        "blind_challenge_test_group_intersection": blind_test_intersection,
        "test_seal_from_manifest": test_seal,
        "preflight_status": prepared["preflight"]["status"],
        "preflight_issues": prepared["issues"],
        "optimizer_updates_planned": 64,
        "blind_verdict": result["verdict"],
        "developer_role_and_test_limit": "Author knows synthetic source labels and answers blind-input challenge from predeclared rule; test is not blind to author; no script-level test artifact parsing, no test generation/scoring. Product integrity checks read partitions internally.",
        "test_generation_performed": False,
        "training_started": False,
        "inference_performed": False,
        "elapsed_seconds": time.monotonic() - started,
        "next_phase": [
            "Wait for parent authorization; reload session/run and revalidate immutable test seal and frozen suite",
            "TrainingRunService.start only for this prepared real run; monitor real worker status/logs; do not manufacture a direct-SFT receipt",
            "Dev-only same eight fixed questions: fresh base, real training adapter, actual merged HF artifact, Q4_K_M GGUF from real export evidence",
            "Use actual workbench export plan/execute with pinned existing llama toolchain; bind GGUF/runtime/export-evidence/training identities",
            "Require strict greedy token proof and equal complete input IDs/EOS across comparison models; preserve raw outputs and any failure; no test scoring",
        ],
    }
    write(out / "preparation-summary.json", summary)
    write(out / "session-prepared-snapshot.json", session.model_dump())
    event(
        "prepared_not_started",
        session_id=session.session_id,
        run_id=prepared["run_id"],
        counts=summary["row_counts"],
        preflight=summary["preflight_status"],
    )


if __name__ == "__main__":
    main()
