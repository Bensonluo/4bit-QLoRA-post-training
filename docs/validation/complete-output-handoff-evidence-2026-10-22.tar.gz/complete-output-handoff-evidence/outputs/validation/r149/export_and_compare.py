#!/usr/bin/env python3
"""R149 future execution: real exports and four-model, development-only comparison.

Nothing runs without --execute or --verify-only. Training must already have a
successful real workbench receipt. This script never starts training, calls final
acceptance, installs tools, updates LM Studio, or rewrites an existing export.
The synthetic data author knows its labels: this is developer integration
evidence, not independent business validation.

Future execution, only after the parent releases the completed training run:
  ./venv/bin/python outputs/validation/r149/export_and_compare.py --execute

The main process invokes --verify-only in a fresh Python process after saving the
real report. Verification loads tokenizers and hashes files, never model weights
into a model or performs inference. Mandatory product integrity checks internally
read all partitions; script-level question/answer access is validation-only.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
from dataclasses import asdict, replace
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
ROOT = REPO / "outputs/validation/r149"
PREPARED = ROOT / "prepared"
EXPECTED_SESSION = "d69fc5181a014671985b671dc698fcf3"
EXPECTED_RUN = "wb-0dfbfbee65f040e3bf4e2d023646783e"
EXPECTED_COMMIT = "dff1c73e2629faf3efc32c39967981fa15a3d0a7"
TOOLS = REPO / "outputs/local-tools/llama.cpp-436f6f89e1e5"
RUNTIME = TOOLS / "build-tunesmith-eval/bin/tunesmith-gguf-eval"
QUANTIZATION = "q4_k_m"
MAX_NEW_TOKENS = 16
LABELS = ("基础模型", "训练适配器", "合并 HF", "GGUF Q4_K_M")
sys.path.insert(0, str(REPO))


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    Path(path).write_text(
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def output_path(value):
    path = Path(value).expanduser().resolve()
    require(path.is_relative_to(ROOT) and path != ROOT, "Output must be a new child of R149.")
    require(not path.is_relative_to(PREPARED), "Prepared training/data evidence is read-only here.")
    return path


def offline(out):
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["HF_DATASETS_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_DATASETS_CACHE"] = str(out / "cache/datasets")
    os.environ["TOKENIZERS_PARALLELISM"] = "false"


def tool_facts():
    """Recheck the already prepared checkout and binary bytes; never build them."""
    inventory = read(PREPARED / "existing-tools-inventory.json")
    require(Path(inventory["directory"]).resolve() == TOOLS, "Unexpected tool checkout.")
    revision = subprocess.check_output(
        ["git", "-C", str(TOOLS), "rev-parse", "HEAD"], text=True, timeout=10
    ).strip()
    require(revision == inventory["revision"], "Prepared llama.cpp revision changed.")
    checked = {}
    for relative, expected in inventory["files"].items():
        path = TOOLS / relative
        require(expected["exists"] and path.is_file(), f"Missing prepared tool: {path}")
        actual = {"sha256": sha(path), "size": path.stat().st_size}
        require(
            all(actual[key] == expected[key] for key in actual),
            f"Prepared tool bytes changed: {relative}",
        )
        checked[relative] = actual
    return {"directory": str(TOOLS), "revision": revision, "files": checked}


def inputs():
    """Read the real completed receipt; no service.start or synthetic receipt."""
    from src.workbench.evaluation_suites import evaluation_cases
    from src.workbench.intake_service import IntakeService
    from src.workbench.sources import content_digest
    from src.workbench.training_runs import TrainingRunService

    prepared = read(PREPARED / "preparation-summary.json")
    require(prepared["session_id"] == EXPECTED_SESSION, "Wrong R149 session.")
    require(prepared["run_id"] == EXPECTED_RUN, "Wrong R149 run.")
    directory = PREPARED / "runs" / EXPECTED_RUN
    # Check the completed worker receipt before get_status can consult any runner.
    result = read(directory / "result.json")
    require(
        result.get("run_id") == EXPECTED_RUN and result.get("status") == "succeeded",
        "Wait for the original workbench worker to finish successfully before executing.",
    )
    training = TrainingRunService(PREPARED / "runs", project_root=REPO)
    run = training.get_status(EXPECTED_RUN)
    require(run["status"] == "succeeded", "Real training artifacts did not verify.")
    session = IntakeService(PREPARED / "intake").load(EXPECTED_SESSION)
    require(session.revision == prepared["session_revision"], "Session revision changed.")
    require(session.dataset is not None, "Missing prepared dataset.")
    require(
        session.dataset.version == run["dataset_version"] == prepared["dataset_version"]
        and session.dataset.name == prepared["dataset_name"]
        and session.dataset.evaluation_suite == prepared["suite"]
        and run["session_id"] == EXPECTED_SESSION
        and run["config_digest"] == prepared["config_digest"] == content_digest(run["config"]),
        "Prepared data, suite, training config or source lineage changed.",
    )
    require(
        run["config"]["data"]["sft_protocol"] == "alpaca_answer_only_v1",
        "This run must retain its actual public Alpaca answer-only objective.",
    )
    manifest = read(session.dataset.paths["manifest"])
    # This reads only the partition manifest, not test.jsonl or test questions.
    require(
        manifest["splits"]["test"] == prepared["test_seal_from_manifest"],
        "Frozen test seal in the partition manifest changed.",
    )
    selected = evaluation_cases(session, split="validation")
    require(len(selected["records"]) == 8, "The frozen development denominator must remain 8.")
    require(selected["suite_id"] == prepared["suite"]["suite_id"], "Wrong frozen suite.")
    require(
        prepared["row_counts"] == session.dataset.statistics["row_counts"],
        "Prepared partition counts changed.",
    )
    return session, run, selected, manifest["splits"]["test"]


def tokenizer_contract(directory, prompts):
    """Hash complete tokenizer semantics, excluding physical source path names."""
    from transformers import AutoTokenizer

    from src.workbench.sources import content_digest

    tokenizer = AutoTokenizer.from_pretrained(
        directory, local_files_only=True, trust_remote_code=False
    )
    require(
        tokenizer.is_fast, "R149 requires the saved Qwen fast tokenizer for full backend identity."
    )
    facts = {
        "class": type(tokenizer).__name__,
        "vocabulary_sha256": content_digest(tokenizer.get_vocab()),
        "added_vocabulary_sha256": content_digest(tokenizer.get_added_vocab()),
        "backend_sha256": content_digest(json.loads(tokenizer.backend_tokenizer.to_str())),
        "special_tokens_map": tokenizer.special_tokens_map,
        "all_special_ids": tokenizer.all_special_ids,
        "chat_template": tokenizer.chat_template,
        "bos_token_id": tokenizer.bos_token_id,
        "eos_token_id": tokenizer.eos_token_id,
        "pad_token_id": tokenizer.pad_token_id,
        "padding_side": tokenizer.padding_side,
        "truncation_side": tokenizer.truncation_side,
        "clean_up_tokenization_spaces": tokenizer.clean_up_tokenization_spaces,
        "split_special_tokens": tokenizer.split_special_tokens,
        "add_bos_token": getattr(tokenizer, "add_bos_token", None),
        "add_eos_token": getattr(tokenizer, "add_eos_token", None),
        "vocabulary_size": len(tokenizer),
    }
    require(type(tokenizer.eos_token_id) is int, "Missing authoritative scalar EOS.")
    prompt_ids = [tokenizer(prompt, truncation=False)["input_ids"] for prompt in prompts]
    return tokenizer, facts, prompt_ids


def verify(out):
    """Independent read-back; no model construction and no generation calls."""
    from src.data.sft_protocol import LEGACY_PROTOCOL, render_sft_prompt
    from src.workbench.business_evaluation import (
        BusinessEvaluationService,
        _model_identity,
        verify_evaluation_report,
    )
    from src.workbench.evaluation_diagnostics import inspect_model_training_evidence
    from src.workbench.gguf_evaluation import gguf_evaluation_model, verified_gguf_model
    from src.workbench.model_export import plan_model_export
    from src.workbench.sources import canonical, content_digest

    session, run, selected, test_seal = inputs()
    frozen_tools = tool_facts()
    execution = read(out / "execution.json")
    require(
        execution["script_sha256"] == sha(__file__)
        and execution["preparation_summary_sha256"] == sha(PREPARED / "preparation-summary.json"),
        "Execution script or prepared summary changed before independent read-back.",
    )
    report_service = BusinessEvaluationService(out / "reports")
    report = report_service.get_report(execution["evaluation_id"])
    verify_evaluation_report(report)
    require(
        report.dataset["purpose"] == "development_only"
        and report.dataset["split"] == "validation"
        and report.dataset["row_count"] == 8
        and report.protocol["evaluation_key"] == selected["evaluation_key"]
        and report.protocol["generation"] == "greedy_token_contract_v2"
        and report.protocol["prompt_renderer"] == "render_alpaca_prompt_without_answer"
        and report.protocol["scorer"] == "classification_exact"
        and report.protocol["max_new_tokens"] == MAX_NEW_TOKENS,
        "Saved report used a different question, generation or scoring contract.",
    )
    hf, gguf = out / "models/hf", out / "models/gguf-q4_k_m"
    receipts = {}
    for name, path, fmt in (("hf", hf, "hf"), ("gguf", gguf, "gguf")):
        plan = plan_model_export(
            run, path, export_format=fmt, quantization=QUANTIZATION, _verify_content=True
        )
        require(
            plan["status"] == "already_exported", f"Independent export verification failed: {plan}"
        )
        receipts[name] = read(path / "export_evidence.json")
        require(
            receipts[name]["config_digest"] == run["config_digest"]
            and receipts[name]["training_protocol"]["sft_protocol"] == "alpaca_answer_only_v1",
            "Export receipt does not bind the original training objective.",
        )
    require(
        receipts["hf"]["output_files"] == receipts["gguf"]["merged_source_files"],
        "HF export and GGUF conversion did not use byte-identical merged HF files.",
    )
    require(
        receipts["gguf"]["business_evaluation_status"] == "not_run",
        "Export-time status must not be rewritten to inherit later scores.",
    )
    prompts = [render_sft_prompt(row, None, LEGACY_PROTOCOL) for row in selected["records"]]
    tokenizers = {}
    authoritative = None
    tokenizer = None
    for label, path in (
        ("base", run["model_path"]),
        ("merged_hf", hf),
        ("gguf_bundle", gguf / "hf_tokenizer"),
    ):
        loaded, facts, ids = tokenizer_contract(path, prompts)
        if authoritative is None:
            authoritative = (facts, ids)
            tokenizer = loaded
        else:
            require((facts, ids) == authoritative, f"Tokenizer semantics/IDs differ: {label}")
        tokenizers[label] = {
            "directory": str(path),
            "identity_sha256": content_digest(facts),
            "facts": facts,
        }
    require(tokenizer is not None and authoritative is not None, "Missing base tokenizer.")
    model_map = {model["label"]: model for model in report.models}
    require(
        tuple(model_map) == LABELS, "The report must retain all four requested models in order."
    )
    expected_requests = {
        LABELS[0]: (str(Path(run["model_path"]).resolve()), None),
        LABELS[1]: (str(Path(run["model_path"]).resolve()), str(Path(run["output_dir"]).resolve())),
        LABELS[2]: (str(hf), None),
    }
    for label, (base, adapter) in expected_requests.items():
        model = model_map[label]
        require(model["requested_model"]["base_model"] == base, f"Wrong HF source: {label}")
        require(model["requested_model"].get("adapter_path") == adapter, f"Wrong adapter: {label}")
        if model.get("identity"):
            require(
                model["identity"]["base"] == _model_identity(Path(base)),
                f"HF source bytes changed: {label}",
            )
            if adapter:
                require(
                    model["identity"]["adapter"] == _model_identity(Path(adapter)),
                    "Adapter bytes changed.",
                )
    actual_gguf = replace(gguf_evaluation_model(run, gguf, RUNTIME), label=LABELS[3])
    if model_map[LABELS[3]].get("identity"):
        require(
            verified_gguf_model(actual_gguf) == model_map[LABELS[3]]["identity"],
            "GGUF/runtime/source identity changed after generation.",
        )
    training_evidence = {}
    for label in LABELS:
        model = model_map[label]
        if model.get("identity"):
            evidence = inspect_model_training_evidence(model, session, report.dataset)
            if label in (LABELS[1], LABELS[3]):
                require(
                    evidence["status"] == "available"
                    and evidence["training_run_id"] == EXPECTED_RUN,
                    "Training source backtrace failed.",
                )
            elif label == LABELS[2]:
                require(
                    evidence["status"] == "not_available", "Merged HF diagnostic scope changed."
                )
                evidence["independent_export_source_verification"] = {
                    "status": "verified",
                    "method": "Actual HF export receipt, complete output hashes and training source identity; distinct from adapter/GGUF diagnostic provenance.",
                    "receipt_path": str(hf / "export_evidence.json"),
                    "receipt_sha256": sha(hf / "export_evidence.json"),
                    "run_id": receipts["hf"]["run_id"],
                    "config_digest": receipts["hf"]["config_digest"],
                    "source_identity": receipts["hf"]["source_identity"],
                    "output_files": receipts["hf"]["output_files"],
                }
            training_evidence[label] = evidence
    rows_out, incomplete = [], []
    for index, source in enumerate(selected["records"]):
        source_id = source["metadata"]["source_row_id"]
        original = next(row for row in session.full_data.source.rows if row.row_id == source_id)
        preview = next(row for row in session.full_data.preview.rows if row.row_id == source_id)
        require(
            source["metadata"]["source_digest"] == session.full_data.source.digest
            and preview.input == source["input"]
            and preview.target == source["output"],
            "Development question does not trace to the confirmed original row.",
        )
        question = {
            "index": index,
            "source": source["metadata"],
            "prompt": prompts[index],
            "expected": source["output"],
            "source_backtrace": {
                "original_source_file": str(PREPARED / "synthetic-source.jsonl"),
                "original_source_sha256": sha(PREPARED / "synthetic-source.jsonl"),
                "source_digest": session.full_data.source.digest,
                "row_id": original.row_id,
                "line": original.line,
                "original_values": original.values,
            },
            "models": {},
        }
        for label in LABELS:
            model = model_map[label]
            require(len(model["rows"]) == 8, f"Failure rows disappeared from denominator: {label}")
            row = model["rows"][index]
            require(
                row["index"] == index
                and row["source"] == source["metadata"]
                and row["prompt"] == prompts[index]
                and row["expected"] == source["output"],
                "Report question does not match its fixed development source.",
            )
            proof = row.get("token_proof")
            if proof is None:
                require(row["status"] == "failed", "A nonfailed generation lacks token proof.")
                incomplete.append({"model": label, "index": index, "error": row["error"]})
            else:
                require(
                    proof["prompt_token_ids"] == authoritative[1][index],
                    "Actual input IDs differ from authoritative base tokenizer.",
                )
                require(
                    proof["eos_token_ids"] == [tokenizer.eos_token_id],
                    "Actual EOS differs across models.",
                )
                require(
                    tokenizer.decode(proof["generated_token_ids"], skip_special_tokens=True)
                    == row["output"],
                    "Generated IDs do not decode to the stored raw output.",
                )
            question["models"][label] = {
                key: row.get(key)
                for key in (
                    "output",
                    "status",
                    "correct",
                    "field_scores",
                    "truncated",
                    "generated_tokens",
                    "error",
                    "token_proof",
                )
            }
        rows_out.append(question)
    require(tool_facts() == frozen_tools, "Prepared tools changed during verification.")
    write(out / "verified-development-observations.json", rows_out)
    write(out / "verified-training-backtrace.json", training_evidence)
    verification = {
        "status": "verified",
        "evaluation_id": report.evaluation_id,
        "report_sha256": sha(out / "reports" / f"{report.evaluation_id}.json"),
        "report_content_digest": content_digest(asdict(report)),
        "report_status": report.status,
        "comparison_key": report.comparison_key,
        "session_id": EXPECTED_SESSION,
        "run_id": EXPECTED_RUN,
        "dataset_version": run["dataset_version"],
        "config_digest": run["config_digest"],
        "evaluation_key": selected["evaluation_key"],
        "denominator_per_model": 8,
        "tokenizers": tokenizers,
        "all_actual_input_ids_and_eos_equal": not incomplete,
        "missing_generation_proofs": incomplete,
        "models": [
            {
                "label": model["label"],
                "metrics": model["metrics"],
                "errors": model["errors"],
                "row_statuses": [row["status"] for row in model["rows"]],
            }
            for model in report.models
        ],
        "test_seal_from_manifest_unchanged": test_seal,
        "test_generation_or_scoring_performed": False,
        "test_note": "No script-level test question/answer parsing; mandatory product integrity verification reads partitions internally.",
        "source_paths": {
            name: str(PREPARED / "runs" / EXPECTED_RUN / name)
            for name in ("run.json", "result.json", "config.json")
        },
        "source_receipt_hashes": {
            name: sha(PREPARED / "runs" / EXPECTED_RUN / name)
            for name in ("run.json", "result.json", "config.json")
        },
        "export_evidence_sha256": {
            name: sha(path / "export_evidence.json") for name, path in (("hf", hf), ("gguf", gguf))
        },
        "source_statuses": {
            label: {
                "diagnostic_status": evidence["status"],
                "export_receipt_verification": evidence.get(
                    "independent_export_source_verification", {}
                ).get("status"),
            }
            for label, evidence in training_evidence.items()
        },
        "tools": frozen_tools,
        "scope": "Developer-authored synthetic development integration only. Original adapter versus merge versus quantization/runtime can differ; no inherited HF scores, business claim, test evaluation, or native-chat path.",
    }
    # Ensure the reread representation itself is stable before publishing evidence.
    require(
        canonical(asdict(report_service.get_report(report.evaluation_id)))
        == canonical(asdict(report)),
        "Report changed during independent verification.",
    )
    write(out / "independent-verification.json", verification)
    return verification


def execute(out):
    from src.workbench.business_evaluation import (
        BusinessEvaluationService,
        EvaluationModel,
        EvaluationProtocol,
    )
    from src.workbench.gguf_evaluation import gguf_evaluation_model
    from src.workbench.model_export import export_model, plan_model_export

    started = time.monotonic()
    commit = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=REPO, text=True, timeout=10
    ).strip()
    require(commit == EXPECTED_COMMIT, "Current product commit differs from released R148.")
    session, run, selected, _ = inputs()
    frozen_tools = tool_facts()
    # A fresh destination preserves failed attempts and never touches R145/R146.
    out.mkdir(parents=True, exist_ok=False)
    offline(out)

    def event(stage, **facts):
        item = {"stage": stage, "elapsed_seconds": time.monotonic() - started, **facts}
        with (out / "progress.jsonl").open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(item, ensure_ascii=False) + "\n")
        print(json.dumps(item, ensure_ascii=False), flush=True)

    try:
        write(out / "source-run-snapshot.json", run)
        write(out / "fixed-development-cases.json", selected)
        write(
            out / "execution.json",
            {
                "status": "exporting",
                "session_id": EXPECTED_SESSION,
                "run_id": EXPECTED_RUN,
                "preparation_summary_sha256": sha(PREPARED / "preparation-summary.json"),
                "script_sha256": sha(__file__),
                "git_commit": commit,
                "tools": frozen_tools,
                "test_generation_or_scoring_performed": False,
            },
        )
        results = {}
        for name, fmt, path in (
            ("hf", "hf", out / "models/hf"),
            ("gguf", "gguf", out / "models/gguf-q4_k_m"),
        ):
            event("export_started", format=fmt, destination=str(path))
            plan = plan_model_export(
                run,
                path,
                export_format=fmt,
                llama_cpp_dir=TOOLS if fmt == "gguf" else None,
                quantization=QUANTIZATION,
            )
            write(out / f"{name}-export-plan.json", plan)
            results[name] = export_model(plan)
            write(out / f"{name}-export-result.json", results[name])
            event("export_finished", format=fmt, result=results[name]["status"])
        gguf = replace(
            gguf_evaluation_model(run, out / "models/gguf-q4_k_m", RUNTIME), label=LABELS[3]
        )
        models = [
            EvaluationModel(LABELS[0], run["model_path"]),
            EvaluationModel(LABELS[1], run["model_path"], run["output_dir"]),
            EvaluationModel(LABELS[2], str(out / "models/hf")),
            gguf,
        ]
        event(
            "four_model_development_comparison_started", questions=8, max_new_tokens=MAX_NEW_TOKENS
        )
        report = BusinessEvaluationService(out / "reports").compare(
            session,
            models,
            EvaluationProtocol("classification_exact", max_new_tokens=MAX_NEW_TOKENS),
        )
        execution = read(out / "execution.json")
        execution.update(
            status="comparison_saved",
            evaluation_id=report.evaluation_id,
            report_status=report.status,
            export_results=results,
        )
        write(out / "execution.json", execution)
        event("comparison_saved", evaluation_id=report.evaluation_id, status=report.status)
        # Fresh process, real saved report and source artifacts; no runtime_factory mocks.
        with (
            (out / "independent-verification.stdout.log").open("w") as stdout,
            (out / "independent-verification.stderr.log").open("w") as stderr,
        ):
            subprocess.run(
                [sys.executable, str(Path(__file__).resolve()), "--verify-only", str(out)],
                cwd=REPO,
                stdout=stdout,
                stderr=stderr,
                check=True,
            )
        checked = read(out / "independent-verification.json")
        require(tool_facts() == frozen_tools, "Prepared tool bytes changed during execution.")
        execution.update(
            status="completed",
            elapsed_seconds=time.monotonic() - started,
            independent_verification=checked,
        )
        write(out / "execution.json", execution)
        write(out / "summary.json", checked)
        event(
            "completed",
            evaluation_id=report.evaluation_id,
            report_status=report.status,
            models=checked["models"],
        )
    except BaseException as exc:
        failure = {
            "status": "failed",
            "type": type(exc).__name__,
            "message": str(exc),
            "traceback": traceback.format_exc(),
            "elapsed_seconds": time.monotonic() - started,
            "scope": "Preserved real artifacts and any partial reports; no scores fabricated or inherited.",
        }
        write(out / "failure.json", failure)
        event("failed", error=f"{type(exc).__name__}: {exc}")
        raise


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument(
        "--execute",
        action="store_true",
        help="Run only after the completed training run is released by the parent.",
    )
    mode.add_argument(
        "--verify-only",
        metavar="OUTPUT_DIR",
        help="Fresh-process read-back; no model inference/export.",
    )
    parser.add_argument(
        "--output-dir",
        default=str(ROOT / "delivery"),
        help="Fresh output directory strictly below R149.",
    )
    args = parser.parse_args()
    if args.verify_only:
        out = output_path(args.verify_only)
        offline(out)
        result = verify(out)
        print(
            json.dumps({"status": result["status"], "evaluation_id": result["evaluation_id"]}),
            flush=True,
        )
    else:
        execute(output_path(args.output_dir))


if __name__ == "__main__":
    main()
