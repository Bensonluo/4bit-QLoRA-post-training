#!/usr/bin/env python3
"""Start and observe only the explicitly authorized frozen R149 workbench run.
No generation, export, direct training replacement, config edits or recovery.
"""

from __future__ import annotations

import gc
import hashlib
import json
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO))
PREPARED = Path(__file__).resolve().parent / "prepared"
EVIDENCE = Path(__file__).resolve().parent / "training-execution"
RUN = "wb-0dfbfbee65f040e3bf4e2d023646783e"


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def main():
    EVIDENCE.mkdir(exist_ok=False)
    from src.workbench.intake_service import IntakeService
    from src.workbench.sources import content_digest
    from src.workbench.training_runs import TrainingRunService

    summary = json.loads((PREPARED / "preparation-summary.json").read_text())
    assert summary["run_id"] == RUN and summary["status"] == "prepared_not_started"
    intake = IntakeService(PREPARED / "intake")
    session = intake.load(summary["session_id"])
    service = TrainingRunService(
        PREPARED / "runs", project_root=REPO, python_executable=sys.executable
    )
    run_dir = PREPARED / "runs" / RUN
    record = service.get_status(RUN)
    assert record["status"] == "prepared" and not (run_dir / "started").exists()
    assert record["config_digest"] == summary["config_digest"] == content_digest(record["config"])
    assert record["dataset_version"] == summary["dataset_version"] == session.dataset.version
    assert session.dataset.evaluation_suite == summary["suite"]
    manifest = json.loads(Path(session.dataset.paths["manifest"]).read_text())
    seals = {
        split: {
            "sha256": sha(session.dataset.paths[split]),
            "expected_sha256": manifest["splits"][split]["sha256"],
            "row_count": manifest["splits"][split]["row_count"],
        }
        for split in ["validation", "test"]
    }
    assert all(v["sha256"] == v["expected_sha256"] for v in seals.values())
    assert seals["test"]["sha256"] == summary["test_seal_from_manifest"]["sha256"]
    suite_path = Path(summary["suite"]["manifest_path"])
    suite_hash = sha(suite_path)
    config_hash = sha(run_dir / "config.json")
    sources = [
        "config/base.py",
        "src/training/sft_trainer.py",
        "src/data/sft_protocol.py",
        "src/data/sft_collator.py",
        "scripts/workbench_train.py",
        "src/workbench/training_runs.py",
        "src/workbench/training_preflight.py",
    ]
    started = time.monotonic()
    before = {
        "run_id": RUN,
        "utc": datetime.now(timezone.utc).isoformat(),
        "git_head": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=REPO, text=True
        ).strip(),
        "config_file_sha256": config_hash,
        "config_digest": summary["config_digest"],
        "dataset_version": summary["dataset_version"],
        "suite_id": summary["suite"]["suite_id"],
        "suite_manifest_sha256": suite_hash,
        "dev_test_seals": seals,
        "sources": {p: sha(REPO / p) for p in sources},
        "model_identity": record["model_identity"],
        "authorization": "Parent explicitly authorized this exact prepared run after R148 commit; no recovery, no eval/export",
        "script_sha256": sha(__file__),
    }
    write(EVIDENCE / "before-start.json", before)
    shutil.copyfile(run_dir / "config.json", EVIDENCE / "immutable-config.json")
    write(EVIDENCE / "prepared-run-snapshot.json", record)
    launched = service.start(
        RUN, session, acknowledge_warnings=False, recover_technical_failures=False
    )
    write(EVIDENCE / "start-status.json", launched)
    print(
        json.dumps(
            {"event": "started", "run_id": RUN, "status": launched["status"]}, ensure_ascii=False
        ),
        flush=True,
    )
    if launched["status"] != "running":
        raise RuntimeError("Real service start failed; preserve evidence, no retry.")
    polls = []
    while True:
        current = service.get_status(RUN)
        worker = service.runner.get_status(RUN)
        poll = {
            "elapsed_seconds": round(time.monotonic() - started, 3),
            "status": current["status"],
            "worker_status": worker,
        }
        polls.append(poll)
        write(EVIDENCE / "status-polls.json", polls)
        print(json.dumps(poll, ensure_ascii=False), flush=True)
        if worker in {"finished", "failed"}:
            final = service.get_status(RUN)
            break
        if worker == "unknown":
            write(EVIDENCE / "last-status.json", current)
            raise RuntimeError("Worker status unknown; no retry/recovery authorized.")
        time.sleep(5)
    write(EVIDENCE / "finish-status.json", final)
    meta = json.loads((REPO / "outputs/.run_meta.json").read_text())[RUN]
    write(EVIDENCE / "runner-process-record.json", meta)
    shutil.copyfile(meta["log_path"], EVIDENCE / "full-worker.log")
    after_seals = {split: sha(session.dataset.paths[split]) for split in ["validation", "test"]}
    assert after_seals == {k: v["sha256"] for k, v in seals.items()}
    assert sha(suite_path) == suite_hash and sha(run_dir / "config.json") == config_hash
    assert final["config_digest"] == summary["config_digest"]
    write(
        EVIDENCE / "after-finish-seals.json",
        {
            "unchanged": True,
            "dev_test_sha256": after_seals,
            "suite_manifest_sha256": sha(suite_path),
            "immutable_config_sha256": sha(run_dir / "config.json"),
            "sources_unchanged": {p: sha(REPO / p) == before["sources"][p] for p in sources},
        },
    )
    if final["status"] != "succeeded":
        print(
            json.dumps({"event": "failed", "failure": final.get("failure")}, ensure_ascii=False),
            flush=True,
        )
        raise RuntimeError("Real worker failed; preserve artifacts and logs, do not recover.")
    artifact_paths = {k: Path(v) for k, v in final["artifacts"].items()}
    artifact_hashes = {
        k: {"path": str(p), "size": p.stat().st_size, "sha256": sha(p)}
        for k, p in artifact_paths.items()
    }
    state_paths = list(Path(final["output_dir"]).glob("checkpoint-*/trainer_state.json"))
    assert len(state_paths) == 1, state_paths
    state = json.loads(state_paths[0].read_text())
    write(EVIDENCE / "actual-trainer-state.json", state)
    losses = [x for x in state["log_history"] if "loss" in x]
    assert state["global_step"] == 64 and len(losses) == 64
    assert [x["step"] for x in losses] == list(range(1, 65))
    assert all(x["learning_rate"] == 2e-4 for x in losses)
    write(EVIDENCE / "actual-optimizer-updates.json", losses)
    result = {
        "status": "succeeded",
        "run_id": RUN,
        "worker_status": worker,
        "pid": final.get("pid"),
        "worker_exit_observed": True,
        "elapsed_seconds": time.monotonic() - started,
        "finished_at": final.get("finished_at"),
        "global_step": state["global_step"],
        "loss_log_count": len(losses),
        "learning_rates": sorted({x["learning_rate"] for x in losses}),
        "recovery_authorized": False,
        "test_generation_performed": False,
        "evaluation_or_export_performed": False,
        "dev_test_seals_unchanged": True,
        "suite_unchanged": True,
        "config_unchanged": True,
        "artifact_hashes": artifact_hashes,
        "actual_trainer_state_source": str(state_paths[0]),
        "actual_trainer_state_sha256": sha(state_paths[0]),
        "full_log_source": meta["log_path"],
        "full_log_sha256": sha(EVIDENCE / "full-worker.log"),
        "mlflow_run_id": final.get("mlflow_run_id"),
        "metrics": final["metrics"],
        "scope": "Actual product workbench train and durable manifest success only; no generation, business validity or north-star claim",
    }
    write(EVIDENCE / "training-summary.json", result)
    print(
        json.dumps(
            {
                "event": "training_verified",
                "run_id": RUN,
                "global_step": 64,
                "learning_rates": result["learning_rates"],
                "worker_status": worker,
                "seconds": result["elapsed_seconds"],
            },
            ensure_ascii=False,
        ),
        flush=True,
    )
    gc.collect()


if __name__ == "__main__":
    main()
