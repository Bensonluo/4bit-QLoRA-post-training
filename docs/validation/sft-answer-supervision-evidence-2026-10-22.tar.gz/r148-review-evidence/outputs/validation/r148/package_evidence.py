#!/usr/bin/env python3
"""Package sanitized R148 evidence, excluding every model/adapter weight."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[2]
DEST=ROOT/'review-evidence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def scrub(s):
    return s.replace(str(REPO),'<REPO_ROOT>').replace(str(Path.home()),'<USER_HOME>')
def main():
    if DEST.exists():raise ValueError('Preserve review package; choose a fresh directory.')
    DEST.mkdir()
    chosen=[]
    for p in ROOT.rglob('*'):
        rel=p.relative_to(ROOT)
        if not p.is_file() or any(part in {'review-evidence','__pycache__','cache'} for part in rel.parts):continue
        if p.suffix not in {'.json','.jsonl','.py','.log'}:continue
        if p.name in {'tokenizer.json','tokenizer_config.json','generation_config.json'}:continue
        if 'checkpoint-' in str(rel):continue
        chosen.append(p)
    for p in chosen:
        dest=DEST/'outputs/validation/r148'/p.relative_to(ROOT)
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(scrub(p.read_text()))
    settings=json.loads((ROOT/'product-sft/settings.json').read_text())
    for relative,expected in settings['product_sources'].items():
        p=REPO/relative
        assert sha(p)==expected, f'Product source changed after real run: {relative}'
        dest=DEST/'source_snapshot'/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_text(scrub(p.read_text()))
    readme='''# R148 synthetic mechanism evidence

This package contains scripts, synthetic data, full prompt/generated token IDs, actual labels, per-step losses/LRs, consumed product-collator rows, hashes and logs. It contains no base or adapter weights. Absolute user/repository prefixes are replaced by placeholders; original evidence remains unchanged locally. File hashes below bind the sanitized package; audit_results.json binds actual local base files after runs.

v1 is preserved historical evidence with a known ticket-ID shortcut and must not be used as clean signal generalization. v2 counterbalances ticket IDs and note styles across all four signals and both output forms. Train32/development16 prompts differ. These counterfactual cases are not independent real business tickets or held-out business validation.

The controlled v2 three arms use FP32, identical initialization/seed/data/sample order, rank8 all-linear LoRA, batch1, 64 AdamW updates, constant2e-4 LR, no warmup. Raw output is scored without extraction or EOS repair. Classification and strict whole-object JSON are each8 development cases. Baseline raw Alpaca truncates16/16; native nonthinking baseline completes16/16 but accepts2/16. Trained full-prompt accepts12/16, Alpaca answer-only16/16, native answer-only12/16; all trained arms complete16/16. This small one-seed result does not establish general superiority, finance task success, or the cause of R146 failures.

The separate integrated smoke uses the actual product SFTTrainer prepare_model/prepare_data/setup_trainer/train path, actual unmodified protocol collator with observation only, FP32 training and default LocalEvaluationRuntime precision for both base and adapter. Framework sample ordering differs from controlled arms; do not treat it as a fourth matched arm. Its exact outcome is in product-sft/results.json. Product automatically evaluates and checkpoints at final step64. A first instrumentation attempt wrongly counted those development rows as training; preserve its complete logs/adapter hash metadata as a failed evidence-collection attempt. No optimizer or score parameter was changed for the rerun.

To reproduce within a checkout containing matching product source, place outputs/validation/r148 here in the repository and run each script with that repository's venv Python -B. Local Qwen3-1.7B must already exist under the documented home cache path; no script downloads a model. Use fresh output destinations: scripts refuse to overwrite completed output. Source snapshots are review context, not an installer. audit_evidence.py validates original local paths and adapter hashes and is intended for original working evidence; this weight-free sanitized package cannot rehash omitted adapters.

Successful runtime costs are recorded in each results.json; no wall-power meter was available, so electricity remains unmeasured. No existing business holdout was accessed.
'''
    (DEST/'README.md').write_text(readme)
    manifest={str(p.relative_to(DEST)):{'size':p.stat().st_size,'sha256':sha(p)} for p in sorted(DEST.rglob('*')) if p.is_file()}
    (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    archive=ROOT/'r148-review-evidence.tar.gz'
    with tarfile.open(archive,'w:gz') as t:t.add(DEST,arcname='r148-review-evidence')
    (ROOT/'review-package.json').write_text(json.dumps({'archive':str(archive),'size':archive.stat().st_size,'sha256':sha(archive),'files':len(manifest),'weights_included':False},indent=2)+'\n')
    print(json.dumps({'archive':str(archive),'size':archive.stat().st_size,'sha256':sha(archive),'files':len(manifest)}))
if __name__=='__main__':main()
