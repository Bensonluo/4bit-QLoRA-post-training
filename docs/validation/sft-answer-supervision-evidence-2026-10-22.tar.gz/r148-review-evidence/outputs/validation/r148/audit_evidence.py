#!/usr/bin/env python3
"""Read and independently validate R148 saved evidence; never loads model weights."""
import hashlib
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def judge(case,text):
    if case['form']=='classification':return text.strip()==case['output'],text.strip() in {'K7','M2','P4','Q9'}
    def unique(pairs):
        d={}
        for k,v in pairs:
            if k in d:raise ValueError('duplicate key')
            d[k]=v
        return d
    try:v=json.loads(text,object_pairs_hook=unique)
    except ValueError:return False,False
    valid=isinstance(v,dict) and set(v)=={'route','ticket'} and all(type(x) is str for x in v.values())
    return valid and v==json.loads(case['output']),valid

def validate_controlled(directory,tokenizer):
    r=json.loads((directory/'results.json').read_text())
    s=json.loads((directory/'settings.json').read_text())
    data=json.loads((directory/'data.json').read_text())
    cases={x['case_id']:x for x in data['development']}
    assert r['status']=='completed'
    assert len({v['initial_lora_sha256'] for v in r['arms'].values()})==1
    assert not ({(x['instruction'],x['input']) for x in data['train']} & {(x['instruction'],x['input']) for x in data['development']})
    if directory.name=='v2':
        for split in data:
            variants={}
            for row in data[split]:variants.setdefault((row['form'],row['signal']),set()).add((row['group_id'],row['input'].split('备注: ')[1]))
            assert len({tuple(sorted(v)) for v in variants.values()})==1
    for arm,value in r['arms'].items():
        steps=value['steps']
        assert len(steps)==64 and [x['step'] for x in steps]==list(range(1,65))
        assert [x['case_id'] for x in steps]==s['sample_order']
        assert all(x['lr']==2e-4 for x in steps)
        assert sha(Path(value['adapter'])/'adapter_model.safetensors')==value['adapter_sha256']
    evaluations={f'base/{k}':v for k,v in r['baseline'].items()}
    evaluations.update({f'trained/{k}':v['evaluation'] for k,v in r['arms'].items()})
    for label,value in evaluations.items():
        rows=value['rows']
        assert set(x['case_id'] for x in rows)==set(cases)
        for row in rows:
            correct,valid=judge(cases[row['case_id']],row['output'])
            assert tokenizer.decode(row['generated_ids'],skip_special_tokens=True)==row['output']
            assert tokenizer(row['prompt'],add_special_tokens='native_chat' not in label)['input_ids']==row['prompt_ids']
            eos=bool(row['generated_ids'] and row['generated_ids'][-1]==row['eos_token_id'])
            truncated=len(row['generated_ids'])>=s['max_new_tokens'][row['form']] and not eos
            assert (correct,valid,eos,truncated)==(row['raw_output_matches'],row['format_valid'],row['eos_observed'],row['truncated'])
            assert row['accepted']==(correct and eos and not truncated)
        for form,summary in value['summary'].items():
            selected=[x for x in rows if form=='all' or x['form']==form]
            assert summary['total']==len(selected)
            for source,target in [('eos_observed','eos'),('truncated','truncated'),('format_valid','format_valid'),('accepted','accepted')]:assert sum(x[source] for x in selected)==summary[target]
    for arm,entries in json.loads((directory/'supervision.json').read_text()).items():
        for row in entries:
            assert len(row['input_ids'])==len(row['labels'])
            assert row['effective_supervised_tokens']==sum(x!=-100 for x in row['labels'][1:])
            if 'full_prompt' not in arm:
                assert all(x==-100 for x in row['labels'][:row['prompt_tokens']])
                assert row['supervised_eos']==1 and all(x==-100 for x in row['post_eos_labels'])
    return {k:v['summary'] for k,v in evaluations.items()}

def main():
    from transformers import AutoTokenizer
    base=Path.home()/'.cache/huggingface/hub/Qwen/Qwen3-1___7B'
    tokenizer=AutoTokenizer.from_pretrained(base,local_files_only=True,trust_remote_code=False)
    summaries={name:validate_controlled(path,tokenizer) for name,path in [('v1_known_identifier_confound',ROOT),('v2_counterbalanced_nuisance',ROOT/'v2')]}
    product=ROOT/'product-sft'
    if (product/'results.json').exists():
        r=json.loads((product/'results.json').read_text())
        assert r['status']=='completed'
        d=json.loads((ROOT/'v2/data.json').read_text());cases={x['case_id']:x for x in d['development']}
        for label,v in r['evaluations'].items():
            assert len(v['rows'])==16
            for row in v['rows']:
                proof=row['token_proof'];ids=proof['generated_token_ids']
                assert tokenizer.decode(ids,skip_special_tokens=True)==row['output']
                assert tokenizer(row['prompt'])['input_ids']==proof['prompt_token_ids']
                correct,valid=judge(cases[row['case_id']],row['output'])
                eos=bool(ids and ids[-1] in proof['eos_token_ids'])
                assert row['accepted']==(correct and eos and not row['truncated'])
                assert valid==row['format_valid']
        assert r['training']['global_step']==64
        consumed=json.loads((product/'consumed_supervision.json').read_text())
        assert sum(x['split']=='train' for x in consumed)==64
        assert sum(x['split']=='development' for x in consumed)==16
        assert all(x['supervised_eos']==1 for x in consumed)
        summaries['product_integrated_smoke']={k:v['summary'] for k,v in r['evaluations'].items()}
    identity={}
    for p in sorted(base.rglob('*')):
        if p.is_file() and (p.suffix in {'.safetensors','.json','.jinja'} or p.name in {'vocab.json','merges.txt'}):identity[str(p.relative_to(base))]={'size':p.stat().st_size,'sha256':sha(p)}
    result={'audit':'passed','scope':'Recompute raw-output scores, EOS, IDs, controlled-arm symmetry, counterbalanced nuisance, actual product collator consumption; no model inference.','summaries':summaries,'base_post_run_files':identity,'limits':['Single model, single seed, four synthetic arbitrary associations, small development counterfactual set.','v1 has a known ticket-ID class shortcut; retain as confounded historical evidence.','Not independent real tickets, held-out business generalization, or an explanation of R146 finance results.','Controlled FP32 arms and default-precision product smoke are separate experiments.','No power meter; electricity unmeasured.']}
    (ROOT/'audit_results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'audit':'passed','summaries':summaries},ensure_ascii=False))
if __name__=='__main__':main()
